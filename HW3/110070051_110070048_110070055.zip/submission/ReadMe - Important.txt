Because of the limitations of the moodle and as per instruction of professor on moodle, I'm removing all but one video from the submission folder.
Complete video results are made available in a online folder link for which is provided in report.

Also, removed are MMRead files because of the same limitations. To run the files in the 'Video Stabilization' folder, please paste files from 'mmread.zip' provided. 